To run the porgram using command line arguments run it like the following example:

	java TaxiClusters.java yellow_tripdata_2009-01-15_1hour_clean.csv 0.0001 5

So first is the file name, second is the epsilon value and third is the minpts
